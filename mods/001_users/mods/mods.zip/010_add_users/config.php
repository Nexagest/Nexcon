<?php
$config['mod']['id'] = 'users->add:user';
$config['mod']['name'] = 'Añadir';
$config['mod']['icon'] = '_0009_Add.png';
$config['mod']['enabled'] = false;
$config['mod']['access'] = array(3);
?>