<?php
$config['mod']['id'] = 'users->edit:user';
$config['mod']['name'] = 'Modificar';
$config['mod']['icon'] = '_0018_Pencil.png';
$config['mod']['enabled'] = false;
$config['mod']['access'] = array(3);
?>