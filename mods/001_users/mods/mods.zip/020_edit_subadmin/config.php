<?php
$config['mod']['id'] = 'users->edit:subadmin';
$config['mod']['name'] = 'Modificar';
$config['mod']['icon'] = '_0018_Pencil.png';
$config['mod']['enabled'] = false;
$config['mod']['access'] = array(2);
?>