function add(){
	var check_id;
}
function add.check_id = function(id){
	
};