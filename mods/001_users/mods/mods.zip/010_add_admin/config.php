<?php
$config['mod']['id'] = 'users->add:admin';
$config['mod']['name'] = 'Añadir';
$config['mod']['icon'] = '_0009_Add.png';
$config['mod']['enabled'] = true;
$config['mod']['access'] = array(1,2);
?>