<?php
$config['mysql']['host'] = 'localhost';
$config['mysql']['port'] = '3306';
$config['mysql']['user'] = 'root';
$config['mysql']['pass'] = '';
$config['mysql']['data'] = 'nexcon';
?>