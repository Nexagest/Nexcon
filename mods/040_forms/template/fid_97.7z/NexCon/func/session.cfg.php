<?php
$config['session']['pfix'] = 'nx';
$config['session']['name'] = 'login';
?>