<?php
include_once('session.cfg.php');
session_start();
$session_name = $config['session']['pfix'] . '.' . $config['session']['name'];
?>