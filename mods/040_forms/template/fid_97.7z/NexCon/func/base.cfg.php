<?php
$config['base']['name'] = 'NexCon';
$config['base']['foot'] = 'nexagest.es';
$config['base']['bdir'] = '/www/NexCon/';
?>