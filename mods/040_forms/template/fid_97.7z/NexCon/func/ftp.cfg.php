<?php
$config['ftp']['host'] = 'localhost';
$config['ftp']['user'] = 'prueba';
$config['ftp']['pass'] = 'prueba';
$config['ftp']['dir'] = 'CLIENTES/';
