<?php
include_once('../base.inc.php');
include_once('is_logged.inc.php');
echo is_logged();
?>