<?php
	header( 'Location: ../' ) ;
?>