<?php
$config['mod']['id'] = 'notifications';
$config['mod']['name'] = 'Notificaciones';
$config['mod']['icon'] = 'letter_64.png';
$config['mod']['enabled'] = true;
$config['mod']['access'] = array(1);
?>