<?php
$config['mod']['id'] = 'groups';
$config['mod']['name'] = 'Grupos';
$config['mod']['icon'] = 'star1_64.png';
$config['mod']['enabled'] = true;
$config['mod']['access'] = array(1);
?>