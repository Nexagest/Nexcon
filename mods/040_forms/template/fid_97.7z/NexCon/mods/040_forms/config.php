<?php
$config['mod']['id'] = 'forms';
$config['mod']['name'] = 'Formularios';
$config['mod']['icon'] = 'document_pencil_64.png';
$config['mod']['enabled'] = true;
$config['mod']['access'] = array(1);
?>