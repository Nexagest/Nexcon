<?php
$config['mod']['id'] = 'documents';
$config['mod']['name'] = 'Documentos';
$config['mod']['icon'] = 'briefcase_64.png';
$config['mod']['enabled'] = true;
$config['mod']['access'] = array(0);
?>