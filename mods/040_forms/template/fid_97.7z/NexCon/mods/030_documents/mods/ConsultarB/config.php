<?php
$config['mod']['id'] = 'documents_user';
$config['mod']['name'] = 'Documentos';
$config['mod']['icon'] = 'up_64.png';
$config['mod']['enabled'] = true;
$config['mod']['access'] = array(3,4);
?>