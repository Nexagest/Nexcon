<?php
$config['mod']['id'] = 'documents';
$config['mod']['name'] = 'Documentos';
$config['mod']['icon'] = 'document_64.png';
$config['mod']['enabled'] = true;
$config['mod']['access'] = array(1,2);
?>