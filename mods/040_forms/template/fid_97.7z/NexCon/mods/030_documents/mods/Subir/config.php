<?php
$config['mod']['id'] = 'upload';
$config['mod']['name'] = 'Subir';
$config['mod']['icon'] = 'up_64.png';
$config['mod']['enabled'] = true;
$config['mod']['access'] = array(1,2);
?>