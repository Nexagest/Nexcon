<?php
$config['mod']['id'] = 'users';
$config['mod']['name'] = 'Usuarios';
$config['mod']['icon'] = 'user_info_64.png';
$config['mod']['enabled'] = true;
$config['mod']['access'] = array(0);
?>