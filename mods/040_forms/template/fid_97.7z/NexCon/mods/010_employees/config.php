<?php
$config['mod']['id'] = 'employees';
$config['mod']['name'] = 'Empleados';
$config['mod']['icon'] = 'user3_64.png';
$config['mod']['enabled'] = false;
$config['mod']['access'] = array(1);
?>