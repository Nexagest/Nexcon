<?php
$conf_file = '../../config.php';
include('../../inc/configuration.inc.php');
$clients = $conf->conn->query('SELECT * FROM clients');
while($client = $clients->fetch_assoc()){
	echo '<li><a href="#" onclick="document.view_client('. $client['id'] .');";>' . $client['name'] . '<p>' . $client['cif'] . '</p></a></li>';
}
?>
