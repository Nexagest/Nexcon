<?php
$config['mod']['id'] = 'employees->consult';
$config['mod']['name'] = 'Consultar';
$config['mod']['icon'] = '_0011_Info.png';
$config['mod']['enabled'] = true;
$config['mod']['access'] = array(1);
?>