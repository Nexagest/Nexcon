<?php
$config['mod']['id'] = 'employees->edit';
$config['mod']['name'] = 'Modificar';
$config['mod']['icon'] = '_0018_Pencil.png';
$config['mod']['enabled'] = true;
$config['mod']['access'] = array(1);
?>