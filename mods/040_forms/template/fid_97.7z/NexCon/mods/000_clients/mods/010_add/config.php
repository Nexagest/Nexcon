<?php
$config['mod']['id'] = 'clients->add';
$config['mod']['name'] = 'Añadir';
$config['mod']['icon'] = '_0009_Add.png';
$config['mod']['enabled'] = true;
$config['mod']['access'] = array(1);
?>