<?php
	include_once('check_id.func.php');
	$id = $_REQUEST['id'];
	echo check_id($id);
?>