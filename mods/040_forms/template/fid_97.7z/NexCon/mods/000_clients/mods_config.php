<?php
	$mods['consult']	=	'000_consult';
	$mods['add']		=	'010_add';
	$mods['edit']		=	'020_edit';
?>