<?php
$config['mod']['id'] = 'clients';
$config['mod']['name'] = 'Clientes';
$config['mod']['icon'] = 'address_64.png';
$config['mod']['enabled'] = true;
$config['mod']['access'] = array(1,2);
?>